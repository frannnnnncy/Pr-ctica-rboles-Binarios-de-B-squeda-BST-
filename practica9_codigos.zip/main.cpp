// ── main.cpp ────────────────────────────────────────────────────────────
#include "ArbolAcademico.hpp"
#include <iostream>
#include <iomanip>

using namespace una_puno;

int main() {
    std::cout << "=== BST Sistema Academico UNA-PUNO (C++17) ===\n\n";

    ArbolAcademico arbol;

    arbol.insertar({20210500,"Mamani Quispe, Juan", "Ing. Sistemas",15.8f,120,EstadoAcademico::ACTIVO, "2021-I"});
    arbol.insertar({20210300,"Huanca Apaza, Maria", "Ing. Civil", 14.2f,110,EstadoAcademico::ACTIVO, "2021-I"});
    arbol.insertar({20210700,"Condori Flores, Pedro", "Medicina", 17.1f,130,EstadoAcademico::ACTIVO, "2021-I"});
    arbol.insertar({20210100,"Ticona Lupaca, Rosa", "Contabilidad", 12.0f, 90,EstadoAcademico::SUSPENDIDO,"2021-I"});
    arbol.insertar({20210400,"Larico Ccama, Carlos", "Ing. Sistemas",16.5f,115,EstadoAcademico::ACTIVO, "2021-I"});
    arbol.insertar({20210600,"Cutipa Vargas, Elena", "Agronomia", 13.7f,100,EstadoAcademico::ACTIVO, "2021-I"});
    arbol.insertar({20210900,"Pari Choque, Luis", "Ing. Sistemas",18.3f,140,EstadoAcademico::EGRESADO, "2021-I"});

    arbol.imprimirArbol();

    std::cout << "\n-- In-Order (ordenado por codigo) --\n";
    std::cout << std::left
              << std::setw(12) << "CODIGO"
              << std::setw(35) << "NOMBRE"
              << std::setw(20) << "ESCUELA"
              << "PPA" << '\n';
    std::cout << std::string(70, '-') << '\n';
    for (const auto& e : arbol.inOrder()) e.print();

    std::cout << "\n-- Pre-Order (codigos) --\n";
    for (const auto& e : arbol.preOrder()) std::cout << e.codigo << " ";
    std::cout << '\n';

    std::cout << "\n-- BFS (nivel por nivel) --\n";
    for (const auto& e : arbol.bfs()) std::cout << e.codigo << " ";
    std::cout << '\n';

    std::cout << "\nAltura del arbol: " << arbol.altura() << '\n';

    std::cout << "\n-- Busqueda --\n";
    auto res = arbol.buscar(20210700);
    if (res) { std::cout << "Encontrado: "; res->print(); }
    auto noExiste = arbol.buscar(99999999);
    std::cout << "Buscar 99999999: "
              << (noExiste ? "encontrado" : "no encontrado") << '\n';

    std::cout << "\n-- Estudiantes con PPA >= 15.0 --\n";
    for (const auto& e : arbol.porRangoPPA(15.0f)) e.print();

    std::cout << "\n-- Estadisticas --\n";
    arbol.estadisticas();

    std::cout << "\n-- Eliminando codigo 20210300 --\n";
    arbol.eliminar(20210300);
    std::cout << "Nodos restantes: " << arbol.inOrder().size() << '\n';
    std::cout << "In-Order: ";
    for (const auto& e : arbol.inOrder()) std::cout << e.codigo << " ";
    std::cout << '\n';

    std::cout << "\n-- BFS despues de eliminar --\n";
    for (const auto& e : arbol.bfs()) std::cout << e.codigo << " ";
    std::cout << '\n';

    std::cout << "\n-- Arbol resultante (estructura ASCII) --\n";
    arbol.imprimirArbol();

    // ── Actividad 7 (equivalente C++) ────────────────────────────────
    std::cout << "\n=== ACTIVIDAD 7 (C++) ===\n";

    std::cout << "\n-- 7.2 Post-Order (ejemplo del marco teorico) --\n";
    ArbolAcademico arbolTeorico;
    int claves[] = {20000050, 20000030, 20000070, 20000020, 20000040, 20000060, 20000080};
    for (int c : claves)
        arbolTeorico.insertar({c, "Est_" + std::to_string(c), "Ingenieria", 15.0f, 100,
                                EstadoAcademico::ACTIVO, "2024-I"});
    std::cout << "In-Order  : ";
    for (const auto& e : arbolTeorico.inOrder()) std::cout << (e.codigo - 20000000) << " ";
    std::cout << "\nPre-Order : ";
    for (const auto& e : arbolTeorico.preOrder()) std::cout << (e.codigo - 20000000) << " ";
    std::cout << "\nPost-Order: ";
    for (const auto& e : arbolTeorico.postOrder()) std::cout << (e.codigo - 20000000) << " ";
    std::cout << "\nBFS       : ";
    for (const auto& e : arbolTeorico.bfs()) std::cout << (e.codigo - 20000000) << " ";
    std::cout << '\n';

    std::cout << "\n-- 7.3 maximo() --\n";
    auto maxEst = arbol.maximo();
    if (maxEst) std::cout << "Codigo maximo: " << maxEst->codigo << " (" << maxEst->nombre << ")\n";

    std::cout << "\n-- 7.4 buscarRangoCodigo(20210200, 20210700) --\n";
    for (const auto& e : arbol.buscarRangoCodigo(20210200, 20210700))
        std::cout << e.codigo << " ";
    std::cout << '\n';

    return 0;
}
