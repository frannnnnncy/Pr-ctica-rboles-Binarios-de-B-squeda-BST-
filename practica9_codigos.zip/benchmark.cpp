// ── benchmark.cpp ───────────────────────────────────────────────────────
#include "ArbolAcademico.hpp"
#include <chrono>
#include <random>
#include <algorithm>
#include <unordered_map>

using namespace una_puno;
using Clock = std::chrono::high_resolution_clock;

std::vector<Estudiante> generarDatos(int n) {
    std::mt19937 rng(42);
    std::uniform_int_distribution<int> distCod(20000000, 29999999);
    std::uniform_real_distribution<float> distPPA(8.0f, 20.0f);

    std::vector<int> codigos;
    while ((int)codigos.size() < n) {
        int c = distCod(rng);
        codigos.push_back(c);
    }
    std::sort(codigos.begin(), codigos.end());
    codigos.erase(std::unique(codigos.begin(), codigos.end()), codigos.end());
    // Si hubo duplicados, generar los faltantes hasta alcanzar n unicos
    while ((int)codigos.size() < n) {
        int c = distCod(rng);
        if (!std::binary_search(codigos.begin(), codigos.end(), c)) {
            codigos.insert(std::upper_bound(codigos.begin(), codigos.end(), c), c);
        }
    }
    codigos.resize(n);
    std::shuffle(codigos.begin(), codigos.end(), rng);

    std::vector<Estudiante> datos;
    for (int i = 0; i < n; i++)
        datos.emplace_back(codigos[i], "Estudiante_" + std::to_string(i),
                            "Ingenieria", 10.0f + distPPA(rng) * 0.5f,
                            100, EstadoAcademico::ACTIVO, "2024-I");
    return datos;
}

void benchmark(int n) {
    auto datos = generarDatos(n);
    int buscarCod = datos[n / 2].codigo;

    // Inserción BST
    ArbolAcademico arbol;
    auto t0 = Clock::now();
    for (auto& e : datos) arbol.insertar(e);
    auto t1 = Clock::now();
    double ms_ins_bst = std::chrono::duration<double, std::milli>(t1-t0).count();

    // Búsqueda BST
    auto t2 = Clock::now();
    arbol.buscar(buscarCod);
    auto t3 = Clock::now();
    double ms_bus_bst = std::chrono::duration<double, std::milli>(t3-t2).count();

    // Inserción unordered_map (equivalente al dict de Python)
    std::unordered_map<int, Estudiante> mapa;
    mapa.reserve(n);
    auto t4 = Clock::now();
    for (auto& e : datos) mapa.emplace(e.codigo, e);
    auto t5 = Clock::now();
    double ms_ins_map = std::chrono::duration<double, std::milli>(t5-t4).count();

    // Búsqueda unordered_map
    auto t6 = Clock::now();
    auto it = mapa.find(buscarCod);
    (void)it;
    auto t7 = Clock::now();
    double ms_bus_map = std::chrono::duration<double, std::milli>(t7-t6).count();

    std::cout << std::setw(8) << n
              << " | BST ins: " << std::fixed << std::setprecision(3)
              << std::setw(9) << ms_ins_bst << " ms"
              << " bus: " << std::setw(8) << std::setprecision(5) << ms_bus_bst << " ms"
              << " | Map ins: " << std::setw(9) << std::setprecision(3) << ms_ins_map << " ms"
              << " bus: " << std::setw(8) << std::setprecision(5) << ms_bus_map << " ms"
              << " | altura: " << arbol.altura() << '\n';
}

int main() {
    std::cout << "       N | BST insercion / busqueda          | Map insercion / busqueda          | Altura\n";
    std::cout << std::string(100, '-') << '\n';
    for (int n : {100, 1000, 10000, 100000})
        benchmark(n);
    return 0;
}
